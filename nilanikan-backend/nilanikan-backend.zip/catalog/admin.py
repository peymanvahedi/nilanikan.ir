# catalog/admin.py
from django.contrib import admin
from django.utils.html import format_html
from .models import (
    Category,
    Product,
    ProductImage,
    Bundle,
    BundleImage,
    Banner,
)

# ---------------------------
# Category
# ---------------------------
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "slug", "parent", "created_at")
    search_fields = ("name", "slug")
    prepopulated_fields = {"slug": ("name",)}


# ---------------------------
# Product + Gallery Inline
# ---------------------------
class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 2
    fields = ("preview", "image", "alt", "order", "is_primary")
    readonly_fields = ("preview",)

    def preview(self, obj):
        if not obj or not getattr(obj, "image", None):
            return "—"
        try:
            return format_html(
                '<img src="{}" style="height:60px;border-radius:6px;object-fit:cover;"/>',
                obj.image.url,
            )
        except Exception:
            return "—"

    preview.short_description = "پیش‌نمایش"


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = (
        "id", "name", "sku", "category",
        "price", "stock", "is_active", "is_recommended",  # ⟵ اضافه شد
    )
    list_filter = ("is_active", "is_recommended", "category")  # ⟵ اضافه شد
    list_editable = ("is_active", "is_recommended")  # ⟵ ویرایش سریع
    search_fields = ("name", "sku", "slug")
    prepopulated_fields = {"slug": ("name",)}
    inlines = [ProductImageInline]


# ---------------------------
# Bundle + Gallery Inline
# ---------------------------
class BundleImageInline(admin.TabularInline):
    model = BundleImage
    extra = 3
    fields = ("preview", "image", "alt", "order", "is_primary")
    readonly_fields = ("preview",)

    def preview(self, obj):
        if not obj or not getattr(obj, "image", None):
            return "—"
        try:
            return format_html(
                '<img src="{}" style="height:60px;border-radius:6px;object-fit:cover;"/>',
                obj.image.url,
            )
        except Exception:
            return "—"

    preview.short_description = "پیش‌نمایش"


@admin.register(Bundle)
class BundleAdmin(admin.ModelAdmin):
    list_display = (
        "id", "title", "slug", "bundle_price",
        "active", "is_recommended", "created_at",  # ⟵ اضافه شد
    )
    list_filter = ("active", "is_recommended")  # ⟵ اضافه شد
    list_editable = ("active", "is_recommended")  # ⟵ ویرایش سریع
    search_fields = ("title", "slug")
    prepopulated_fields = {"slug": ("title",)}
    filter_horizontal = ("products",)  # انتخاب راحت محصولات باندل
    inlines = [BundleImageInline]


# ---------------------------
# Banner
# ---------------------------
@admin.register(Banner)
class BannerAdmin(admin.ModelAdmin):
    list_display = ("id", "alt", "is_active", "order", "created_at")
    list_editable = ("is_active", "order")
    search_fields = ("alt",)
    list_filter = ("is_active",)
