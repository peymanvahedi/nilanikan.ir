// src/components/ProductBuyBox.tsx
"use client";

import { useMemo, useState } from "react";
import { ShoppingCart, ShieldCheck, Truck, PhoneCall, Gift } from "lucide-react";
import AttributePicker from "@/components/AttributePicker";
import AddToCartButton from "@/components/AddToCartButton";
import { formatToman } from "@/lib/money";

type Attr = {
  id?: number | string;
  attribute: string;   // مثل "رنگ" یا "سایز"
  value: string;       // مثل "سبز" یا "30"
  slug?: string;
  color_code?: string | null;
};

type Props = {
  /** قیمت نهایی (با تخفیف) */
  price: number;
  /** قیمت قبل از تخفیف (اختیاری) */
  compareAtPrice?: number | null;
  /** موجودی (برای پیام هشدار اختیاری) */
  stock?: number | null;

  /** ویژگی‌ها (از API) برای ساخت پیکرها */
  attributes?: Attr[];

  /** ویژگی‌های قابل‌انتخاب به تفکیک گروه‌ها — اگر ندادی از attributes استنتاج می‌کنم */
  groups?: {
    name: string;             // "رنگ" یا "سایز"
    key: string;              // "color" | "size" | ...
    items: { label: string; value: string; color_code?: string | null }[];
  }[];

  /** نشان‌ها */
  showFreeShipping?: boolean;
  showFastDelivery?: boolean;

  /** کال‌بک افزودن به سبد — اگر از AddToCartButton استفاده می‌کنی لازم نیست */
  onAddToCart?: (payload: {
    qty: number;
    selections: Record<string, string>;
  }) => Promise<void> | void;

  /** پیش‌فرض انتخاب‌ها (مثلا رنگ=سبز) */
  defaultSelections?: Record<string, string>;
};

const faNum = (n: number) => n.toLocaleString("fa-IR");

export default function ProductBuyBox({
  price,
  compareAtPrice = null,
  stock = null,
  attributes = [],
  groups,
  showFreeShipping = true,
  showFastDelivery = true,
  onAddToCart,
  defaultSelections = {},
}: Props) {
  // 1) استنتاج گروه‌های انتخاب از attributes اگر groups نیامده
  const normalizedGroups = useMemo(() => {
    if (groups && groups.length) return groups;
    if (!attributes?.length) return [];
    const map = new Map<string, { name: string; key: string; items: any[] }>();
    for (const a of attributes) {
      const name = a.attribute?.trim() || "ویژگی";
      const key = name.includes("رنگ") ? "color" : name.includes("سایز") ? "size" : name;
      if (!map.has(name)) map.set(name, { name, key, items: [] });
      map.get(name)!.items.push({
        label: a.value,
        value: a.value,
        color_code: a.color_code ?? null,
      });
    }
    return Array.from(map.values());
  }, [attributes, groups]);

  // 2) انتخاب‌ها و تعداد
  const [qty, setQty] = useState<number>(1);
  const [selections, setSelections] = useState<Record<string, string>>(defaultSelections);

  const hasDiscount = typeof compareAtPrice === "number" && compareAtPrice > price;
  const offPercent = hasDiscount ? Math.round(((compareAtPrice! - price) / compareAtPrice!) * 100) : 0;

  const canAdd =
    normalizedGroups.length === 0 ||
    normalizedGroups.every((g) => selections[g.key] && selections[g.key].trim().length > 0);

  const lowStock = typeof stock === "number" && stock > 0 && stock <= 3;

  const handlePick = (key: string, val: string) => {
    setSelections((s) => ({ ...s, [key]: val }));
  };

  const handleAdd = async () => {
    if (!canAdd) return;
    if (onAddToCart) {
      await onAddToCart({ qty, selections });
      return;
    }
    // اگر پروژه‌ات AddToCartButton سفارشی دارد، می‌تونی اینجا آن را صدا بزنی.
    // فعلاً کاری نمی‌کنیم چون پایین از AddToCartButton استفاده می‌کنیم.
  };

  return (
    <aside
      className="rounded-2xl border border-zinc-200 bg-white p-4 sm:p-5 shadow-sm"
      dir="rtl"
    >
      {/* قیمت‌ها */}
      <div className="mb-3 flex items-start justify-between">
        <div>
          {hasDiscount && (
            <span className="inline-block rounded-full bg-rose-600 px-2 py-0.5 text-[11px] font-extrabold text-white">
              %{faNum(offPercent)}
            </span>
          )}
          <div className="mt-1 text-2xl font-extrabold text-rose-600">
            {formatToman(price)} <span className="text-[11px] font-bold">تومان</span>
          </div>
          {hasDiscount && (
            <div className="text-sm text-zinc-400">
              <del>{formatToman(compareAtPrice!)}</del>
            </div>
          )}
          {lowStock && (
            <div className="mt-1 text-xs font-bold text-amber-700">
              تنها {faNum(stock!)} عدد باقی مانده!
            </div>
          )}
        </div>

        {/* برچسب‌ها */}
        <div className="flex flex-col items-end gap-1">
          {showFreeShipping && (
            <div className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-1 text-[11px] font-bold text-emerald-700 ring-1 ring-emerald-100">
              <Truck size={14} />
              ارسال رایگان
            </div>
          )}
          {showFastDelivery && (
            <div className="inline-flex items-center gap-1 rounded-full bg-pink-50 px-2 py-1 text-[11px] font-bold text-pink-700 ring-1 ring-pink-100">
              <Gift size={14} />
              تحویل سریع
            </div>
          )}
        </div>
      </div>

      {/* انتخاب ویژگی‌ها */}
      {normalizedGroups.map((g) => (
        <div key={g.key} className="mb-4">
          <div className="mb-2 text-sm font-bold text-zinc-700">{g.name}</div>

          {/* اگر گروه رنگ است، چیپ رنگی؛ در غیر این‌صورت تراشه ساده */}
          <div className="flex flex-wrap gap-2">
            {g.items.map((it: any, idx: number) => {
              const active = selections[g.key] === it.value;
              const base =
                "h-9 rounded-xl px-3 text-sm font-bold ring-1 transition focus:outline-none";
              if (g.key === "color" || g.name.includes("رنگ")) {
                return (
                  <button
                    key={idx}
                    onClick={() => handlePick(g.key, it.value)}
                    className={`${base} inline-flex items-center gap-2 ${
                      active
                        ? "ring-pink-200 bg-pink-50 text-pink-700"
                        : "ring-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50"
                    }`}
                    type="button"
                    aria-pressed={active}
                  >
                    <span
                      className="inline-block h-4 w-4 rounded-full border"
                      style={{ backgroundColor: it.color_code || undefined }}
                      title={it.color_code || undefined}
                    />
                    {it.label}
                  </button>
                );
              }
              return (
                <button
                  key={idx}
                  onClick={() => handlePick(g.key, it.value)}
                  className={`${base} ${
                    active
                      ? "ring-pink-200 bg-pink-50 text-pink-700"
                      : "ring-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50"
                  }`}
                  type="button"
                  aria-pressed={active}
                >
                  {it.label}
                </button>
              );
            })}
          </div>
        </div>
      ))}

      {/* اگر همه ویژگی‌ها انتخاب نشده‌اند، پیام کوچولو */}
      {normalizedGroups.length > 0 && !canAdd && (
        <p className="mb-3 text-xs font-bold text-rose-600">
          لطفاً همهٔ ویژگی‌های موردنیاز را انتخاب کنید.
        </p>
      )}

      {/* تعداد + افزودن به سبد */}
      <div className="mt-3 flex items-center gap-3">
        <div className="flex items-center rounded-xl ring-1 ring-zinc-200">
          <button
            type="button"
            className="h-10 w-10 text-lg"
            onClick={() => setQty((n) => Math.max(1, n - 1))}
            aria-label="کم کردن تعداد"
          >
            −
          </button>
          <div className="px-3 text-sm font-bold">{faNum(qty)}</div>
          <button
            type="button"
            className="h-10 w-10 text-lg"
            onClick={() => setQty((n) => Math.min(99, n + 1))}
            aria-label="افزودن تعداد"
          >
            +
          </button>
        </div>

        <AddToCartButton
          className="flex-1 h-10 rounded-xl bg-pink-600 text-white font-extrabold hover:bg-pink-700 disabled:opacity-60 disabled:cursor-not-allowed inline-flex items-center justify-center gap-2"
          disabled={!canAdd}
          onClick={handleAdd}
        >
          <ShoppingCart size={18} />
          افزودن به سبد خرید
        </AddToCartButton>
      </div>

      {/* نکات اعتماد */}
      <ul className="mt-4 space-y-2 text-[12px] text-zinc-600">
        <li className="flex items-center gap-2">
          <ShieldCheck size={16} className="text-emerald-600" />
          ضمانت اصالت کالا و سلامت فیزیکی
        </li>
        <li className="flex items-center gap-2">
          <Truck size={16} className="text-pink-600" />
          امکان تعویض سایز تا ۷ روز
        </li>
        <li className="flex items-center gap-2">
          <PhoneCall size={16} className="text-zinc-500" />
          پشتیبانی: ۰۲۱-xxx-xxxx
        </li>
      </ul>
    </aside>
  );
}
