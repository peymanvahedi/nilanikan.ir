"use client";

import { useEffect, useRef } from "react";
import ProductCard, { ProductLike } from "./ProductCard";

export default function CardSlider({
  title,
  items,
  ctaHref,
  ctaText = "مشاهده همه",
  hrefBase = "/product", // مسیر پایه لینک کارت‌ها
  itemRibbon,
  itemRibbonTone = "pink",
  variant = "compact", // ← پیش‌فرض را کوچک می‌گذاریم چون برای «ست‌ها و پافر» می‌خواهیم
}: {
  title?: string;
  items: ProductLike[];
  ctaHref?: string;
  ctaText?: string;
  hrefBase?: string;
  itemRibbon?: string;
  itemRibbonTone?: "pink" | "emerald" | "zinc";
  variant?: "default" | "compact";
}) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
        el.scrollLeft += e.deltaY;
      }
    };
    el.addEventListener("wheel", onWheel, { passive: true });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  const cleanItems = (items ?? [])
    .filter(Boolean)
    .map((it) => ({
      ...it,
      ribbon: (it as any).ribbon ?? itemRibbon,
      ribbonTone: (it as any).ribbonTone ?? itemRibbonTone,
    })) as ProductLike[];

  return (
    <section className="py-6" dir="rtl" aria-label={title}>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg md:text-xl font-extrabold">{title}</h2>
        {ctaHref && (
          <a
            href={ctaHref}
            className="inline-flex h-9 items-center rounded-lg bg-pink-600 px-3 text-white text-sm font-bold hover:bg-pink-700"
          >
            {ctaText}
          </a>
        )}
      </div>

      <div
        ref={containerRef}
        className="flex gap-3 overflow-x-auto snap-x snap-mandatory pb-2"
      >
        {cleanItems.map((it) => (
          <div
            key={(it.slug ?? it.id) as any}
            className={`snap-end shrink-0 ${
              variant === "compact" ? "w-[200px] lg:w-[200px]" : "w-[260px] lg:w-[240px]"
            }`}
          >
            <div dir="rtl">
              <ProductCard item={it} className="w-full" hrefBase={hrefBase} />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
