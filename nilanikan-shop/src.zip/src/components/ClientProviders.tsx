"use client";

import CartProvider from "@/components/CartProvider";
import TourProvider from "@/components/tour/TourProvider";
import PageTour from "@/components/tour/PageTour";

export default function ClientProviders({ children }: { children: React.ReactNode }) {
  return (
    <CartProvider>
      <TourProvider>
        {/* این کامپوننت به صورت خودکار قدم‌های مخصوص هر صفحه رو تزریق می‌کنه */}
        <PageTour />
        {children}
      </TourProvider>
    </CartProvider>
  );
}
