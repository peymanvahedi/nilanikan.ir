// src/components/ProductTabs.tsx
"use client";

import { useMemo, useState } from "react";

type SizeChart = {
  headers: string[];
  rows: Array<Array<string | number>>;
  note?: string;
};

type AttributeValue = {
  id: number;
  attribute: string;     // مثل "Color" یا "Size"
  value: string;         // مثل "Red" یا "M"
  slug: string;
  color_code?: string | null; // مثل "#FF0000"
};

type Props = {
  // می‌تواند آرایهٔ استرینگ (سازگاری قدیم) یا آرایهٔ AttributeValue (حالت جدید) باشد
  features?: Array<string | AttributeValue>;
  description?: string; // HTML
  sizeChart?: SizeChart | null | undefined;
  reviewsEnabled?: boolean;
  initialTab?: "features" | "description" | "size";
};

function isAttrObj(x: any): x is AttributeValue {
  return x && typeof x === "object" && "attribute" in x && "value" in x;
}

export default function ProductTabs({
  features = [],
  description,
  sizeChart,
  reviewsEnabled = false,
  initialTab = "features",
}: Props) {
  const [tab, setTab] = useState<"features" | "description" | "size">(initialTab);

  const normFeatures = useMemo(() => {
    // خروجی یکنواخت: [{label, value, color_code?}, ...]
    const out: { label: string; value: string; color_code?: string | null }[] = [];
    for (const f of features) {
      if (isAttrObj(f)) {
        out.push({ label: f.attribute, value: f.value, color_code: f.color_code ?? null });
      } else if (typeof f === "string") {
        // تلاش برای جدا کردن label: value
        const m = f.match(/^\s*([^:：]+)\s*[:：]\s*(.+)\s*$/);
        if (m) out.push({ label: m[1], value: m[2] });
        else out.push({ label: "ویژگی", value: f });
      }
    }
    return out;
  }, [features]);

  return (
    <div dir="rtl">
      {/* سر تب‌ها */}
      <div className="flex items-center gap-2 border-b border-zinc-200">
        {[
          { id: "features", label: "ویژگی‌ها" },
          { id: "description", label: "توضیحات" },
          { id: "size", label: "جدول سایز" },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id as any)}
            className={`px-3 pb-2 text-sm font-bold ${
              tab === (t.id as any)
                ? "text-pink-600 border-b-2 border-pink-600"
                : "text-zinc-500 hover:text-zinc-700"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* محتوا */}
      <div className="p-4 rounded-b-xl bg-white ring-1 ring-zinc-200 ring-t-0">
        {/* ویژگی‌ها */}
        {tab === "features" && (
          <>
            {normFeatures.length ? (
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
                {normFeatures.map((a, idx) => (
                  <div key={idx} className="flex items-start gap-2 min-w-0">
                    <dt className="text-sm text-zinc-500 w-28 shrink-0">{a.label}</dt>
                    <dd className="text-sm text-zinc-800 break-words">
                      {a.color_code ? (
                        <span className="inline-flex items-center gap-2">
                          <span
                            className="inline-block w-4 h-4 rounded-full border"
                            style={{ backgroundColor: a.color_code || undefined }}
                            title={a.color_code || undefined}
                          />
                          <span>{a.value}</span>
                        </span>
                      ) : (
                        a.value
                      )}
                    </dd>
                  </div>
                ))}
              </dl>
            ) : (
              <div className="text-sm text-zinc-500">ویژگی‌ای ثبت نشده است.</div>
            )}
          </>
        )}

        {/* توضیحات */}
        {tab === "description" && (
          description ? (
            <div
              className="prose prose-sm max-w-none"
              dangerouslySetInnerHTML={{ __html: description }}
            />
          ) : (
            <div className="text-sm text-zinc-500">توضیحاتی ثبت نشده است.</div>
          )
        )}

        {/* جدول سایز */}
        {tab === "size" && (
          sizeChart?.headers?.length && sizeChart?.rows?.length ? (
            <div className="overflow-x-auto">
              <table className="min-w-[520px] w-full text-sm border border-zinc-200 rounded-lg overflow-hidden">
                <thead className="bg-zinc-50">
                  <tr>
                    {sizeChart.headers.map((h, i) => (
                      <th key={i} className="px-3 py-2 text-right font-bold border-b border-zinc-200">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sizeChart.rows.map((r, ri) => (
                    <tr key={ri} className="odd:bg-white even:bg-zinc-50">
                      {r.map((c, ci) => (
                        <td key={ci} className="px-3 py-2 border-b border-zinc-100">
                          {String(c)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              {sizeChart.note && (
                <p className="mt-2 text-xs text-zinc-500">{sizeChart.note}</p>
              )}
            </div>
          ) : (
            <div className="text-sm text-zinc-500">جدول سایزی ثبت نشده است.</div>
          )
        )}
      </div>
    </div>
  );
}
