// postcss.config.js (root) — Tailwind v4
module.exports = {
  plugins: {
    "@tailwindcss/postcss": {},
  },
};
