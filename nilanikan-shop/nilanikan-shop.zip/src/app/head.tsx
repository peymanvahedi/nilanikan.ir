export default function Head() {
  return (
    <>
      <link rel="preload" as="image" href="/banners/banner-2.jpg" />
      <link rel="preload" as="image" href="/banners/banner-3.jpg" />
    </>
  );
}
